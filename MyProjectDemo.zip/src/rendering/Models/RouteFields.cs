using Sitecore.LayoutService.Client.Response.Model.Fields;

namespace MyProject.Models
{
    public class RouteFields
    {
        public TextField PageTitle { get; set; } = default!;
    }
}
