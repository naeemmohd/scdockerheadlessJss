# Serialized Sitecore Items

This path contains serialized Sitecore content items for this example. The
serialized paths are configured in `Items.module.json`.

See Sitecore Content Serialization documentation for more information.