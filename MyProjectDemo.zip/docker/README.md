# Sitecore Containers

This example follows the recommended folder structure for container-based
Sitecore solutions. See Sitecore Containers documentation for more information.

The `clean.ps1` script here can be used to "reset" the state of your containers.
It clears all mounted data and deployed/copied build output.