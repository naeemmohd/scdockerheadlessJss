﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Sitecore.Owin.Authentication.Identity;
using Sitecore.Owin.Authentication.Services;
using Sitecore.SecurityModel.Cryptography;
using System;
using System.Net.Mail;
using System.Security.Claims;
using System.Text;

namespace MyProject.Pipeline
{
    public class CustomExternalUserBuilder : ExternalUserBuilder
    {
        private readonly IHashEncryption _hashEncryption;

        public bool IsPersistentUser
        {
            get;
            set;
        }

        protected ApplicationUserFactory ApplicationUserFactory
        {
            get;
        }

        public CustomExternalUserBuilder(ApplicationUserFactory applicationUserFactory, IHashEncryption hashEncryption)
        {
            _hashEncryption = hashEncryption;
            ApplicationUserFactory = applicationUserFactory;
        }

        public override ApplicationUser BuildUser(UserManager<ApplicationUser> userManager, ExternalLoginInfo externalLoginInfo)
        {
            Sitecore.Diagnostics.Log.Info($" Ad user creation started", this);
            string userName = CreateUniqueUserName(userManager, externalLoginInfo);
            ApplicationUser applicationUser = ApplicationUserFactory.CreateUser(userName);
            applicationUser.IsVirtual = !IsPersistentUser;
            applicationUser.Email = externalLoginInfo.Email;

            Sitecore.Diagnostics.Log.Info($" Ad Application user name {applicationUser.IsVirtual} {applicationUser.Email} ", this);
            return applicationUser;
        }

        protected virtual string CreateUniqueUserName(UserManager<ApplicationUser> userManager, ExternalLoginInfo externalLoginInfo)
        {
            ClaimsIdentity externalIdentity = externalLoginInfo.ExternalIdentity;
            //AD domain used for Azure
            string domain = "sitecore";
            string userName = string.Empty;
            if (externalIdentity != null)
            {
                var emailId = externalIdentity.FindFirst("email")?.Value;
                MailAddress addr = new MailAddress(emailId);
                userName = addr.User;
            }
            else
            {
                userName = GetDefaultUserName(userManager, externalLoginInfo);
            }
            return string.Format("{0}\\{1}", domain, userName);
        }

        protected string GetDefaultUserName(UserManager<ApplicationUser> userManager, ExternalLoginInfo externalLoginInfo)
        {
            if (externalLoginInfo == null)
            {
                throw new InvalidOperationException("Unable to retrieve External Login Info from the Identity provider for the given identity");
            }
            string defaultUserName;
            do
            {
                string text = string.Format("{0}{1}{2}", externalLoginInfo.Login.LoginProvider, externalLoginInfo.Login.ProviderKey, "$");
                byte[] bytes = Encoding.ASCII.GetBytes(text);
                byte[] inArray = _hashEncryption.ComputeHash(bytes);
                defaultUserName = Convert.ToBase64String(inArray).Trim('=').Replace("/", string.Empty).Replace("+", string.Empty);
                defaultUserName = defaultUserName.Substring(0, Math.Min(defaultUserName.Length, 10));
            }
            while (userManager.FindByName(defaultUserName) != null);
            return defaultUserName;
        }
    }
}